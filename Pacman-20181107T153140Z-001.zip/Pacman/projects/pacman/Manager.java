package projects.pacman;

import info.gridworld.actor.*;
import info.gridworld.grid.*;

public class Manager extends Empty
{
    //is a hidden block in grid that manages lives and winning/losing sequence
    private static int lives;

    public Manager()
    {
        lives = 3;
    }

    public static int getLives()
    {
        return lives;
    }

    public static void subLives()
    {
        lives--;
    }

    public void act()
    {
        checkPlayer();//checks if player is in grid
        checkPellets();//checks if no pellets left, then ends game 
    }

    public void checkPellets()
    {
        //checks grid for no pellets left; if no pellets left, display win sequence
        for(int r = 0; r < 23; r++)
        {
            for(int c = 0; c < 23; c++)
            {
                Location loc = new Location (r,c);
                if(getGrid().get(loc) instanceof Pellet)
                    return;
            }
        }
        System.out.println("Congratulations! You've Won!");
        System.exit(0);
    }

    public void checkPlayer()
    {
        if(playerIsNotInGrid())
        {
            if(lives == 1)//after last life, lives didn't change to 0, so 1 is now the last life...
            {
                lives--;//...and then subtracts 1 so 0 is displayed
                System.out.println("Congratulations! You've Lost!");
                System.exit(0);
            }
            Pacman.reset();//moves ghosts back to cage, player back to original location
            //wait 1 second after reset
            try { Thread.sleep(1000); } catch(Exception e) {}
        }
    }

    public boolean playerIsNotInGrid()
    {
        //checks the grid for player, returns true if player is not in the grid
        for(int r = 0; r < 23; r++)
        {
            for(int c = 0; c < 23; c++)
            {
                Location loc = new Location (r,c);
                if(getGrid().get(loc) instanceof Player)
                    return false;
            }
        }
        return true;
    }
}
