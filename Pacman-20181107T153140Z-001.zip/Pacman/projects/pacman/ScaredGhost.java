package projects.pacman;

import info.gridworld.grid.*;
import info.gridworld.actor.*;
import java.util.ArrayList;
import java.util.Random;
/**
 * Write a description of class ScaredGhost here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ScaredGhost extends Ghost
{
    boolean shouldMove;//for moving on alternating acts
    int timer;//how long before ScaredGhost becomes Ghost again

    public ScaredGhost()
    {
        shouldMove = true;
        timer = 25; //determines how long before they change back into ghost objects
    }

    public void act()
    {
        //uses critter type movement
        move(selectMoveLocations(getMoveLocations()));
    }
    
    public Location selectMoveLocations(ArrayList<Location> locs)
    {
        /*if the ghost is near the teleport locations on the left and right, it doesn't add and locations
         * to locs. So, if the size is zero, we know it is in one of the two teleport locations.
         * It then tests to see which location it is in, and returns the other side as its next location
         */
        if(locs.size() == 0)
        {
            if(getLocation().equals(new Location(11,0)))
                return new Location(11,21);
            if(getLocation().equals(new Location(11,22)))
                return new Location(11,1);
        }

        //if getMoveLocations() returned an different arraylist
        //of only the player object, return that location
        if(getGrid().get(locs.get(0)) instanceof Player)
            return locs.get(0);

        int r = (int) (Math.random() * locs.size());
        return locs.get(r);
    }

    public void move(Location loc)
    {
        Grid<Actor> gr = getGrid();
        //scared ghost becomes regular ghost after 20 moves
        if(timer <= 0)
        {
            Ghost g = new Ghost();
            g.setStart(0);
            g.setBool(false);
            g.putSelfInGrid(gr, getLocation());
            return;
        }

        //if selectLocation() returned the location with the player,
        //place a Empty object in my location and a new ghost at the entrance
        if(gr.get(loc) instanceof Player)
        {
            Pacman.setScore(500);//add 500 pts to score, probably should have been named addScore(), oh well
            Ghost g = new Ghost();
            g.setStart(0);
            g.setBool(false);
            g.putSelfInGrid(gr, new Location(9, 11));
            Empty e = new Empty();
            e.putSelfInGrid(gr, getLocation());
            return;
        }
        
        //allows scaredGhost to move every other act()
        if(shouldMove)
        {
            //standard move code from Ghost
            lastLoc = getLocation();
            a2 = gr.get(loc);
            moveTo(loc);
            a1.putSelfInGrid(gr,lastLoc);
            a1 = a2;
            shouldMove = false;
            timer--;
        }
        else
            shouldMove = true;
    }
}

