package projects.pacman;

import info.gridworld.actor.*;
import info.gridworld.grid.*;

/**
 * Serves as the background object. Gridworld was not very nice about letting us change the GUI,
 * so we had to improvise. Placed in the grid to keep the background black. Has no other purpose, mannn
 * 
 * @author (Sean Hurley and Rahul Surti) 
 * @version (Version 1.5: June 3, 2014)
 */
public class Empty extends Flower
{
    public void act()
    {
        //helps make everything run a little smoother by being empty
    }
}
