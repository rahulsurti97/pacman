package projects.pacman;

import info.gridworld.actor.*;
import info.gridworld.grid.*;

import java.awt.Color;

/**
 * Used to stop Actors from moving. 
 * 
 * @author (Sean Hurley and Rahul Surti) 
 * @version (Version 1.5: June 3, 2014)
 */
public class Wall extends Rock
{
    public Wall()
    {
        setColor(null);
        //we have a sprite for it so we dont need to set a color
    }
    
    public void act()
    {
        //we don't need it to do anything
    }
}
