package projects.pacman;

import info.gridworld.grid.*;
import info.gridworld.actor.*;
/**
 * Literally does nothing. Just needs to be there so the other classes can do their thing, bruhh
 * 
 * @author (Sean Hurley and Rahul Surti) 
 * @version (Version 1.5: June 3, 2014)
 */
public class PowerPellet extends Pellet
{
    //just has to be there for scared ghosts, ya know
}
