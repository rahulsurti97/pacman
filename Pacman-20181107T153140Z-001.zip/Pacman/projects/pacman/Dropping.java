package projects.pacman;

import info.gridworld.actor.*;
import info.gridworld.grid.*;
/**
 * Just like Pellet, this class just needs to be there. Sits there and does nothing, duude
 * 
 * @author (Sean Hurley and Rahul Surti) 
 * @version (Version 1.5: June 3, 2014)
 */
public class Dropping extends Flower
{
    public void act()
    {
        //makes things run a little smoother
    }
}
