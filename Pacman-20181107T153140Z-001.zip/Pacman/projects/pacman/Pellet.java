package projects.pacman;

import info.gridworld.actor.*;
import info.gridworld.grid.*;

/**
 * Literally does nothing. Just needs to be there so the other classes can do their thing
 * 
 * @author (Sean Hurley and Rahul Surti) 
 * @version (Version 1.5: June 3, 2014)
 */
public class Pellet extends Flower
{
    public void act()
    {
        //makes things run a little smoother by making it do literally nothing
    }
}
