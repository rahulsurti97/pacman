package projects.pacman;

import info.gridworld.actor.*;
import info.gridworld.grid.*;

/**
 * Runner of Pacman game
 * does stufz
 * 
 * @author (Rahul Surti and Sean "Da Boss" "bossasaurus" "TheVeryBestLikeNoOneEverWas" Hurley) 
 * @version 1.5 June 3rd, 2014
*/
public class Pacman
{
    //creates grid
    public static ActorWorld world = new ActorWorld(new BoundedGrid<Actor>(23,23));
    
    
    /**
     * The only Actor that actually moves in the game.
     * Its direction is controlled by the keyboard arrow keys.
     */
    public static Player player= new Player();
    
    private static int score;
    public static void setScore(int s)//actually adds score to score, should have been named addScore() lol
    {score += s;}

    /**
     * Handles game simulation with one bug who moves
     */

    public static void main(String[] args)
    {
        createWalls();//does wut da name sayz
        putPellets();//same
        createGhosts();//dis too
        world.add(new Location (9, 0), new Manager());//puts a discreet manager object in a place sealed off by Walls
        world.add(new Location (18, 13), player);//puts player in grid
        player.setDirection(270);

        //borrowed some code from snake to listen to key presses to set direction
        java.awt.KeyboardFocusManager.getCurrentKeyboardFocusManager()
        .addKeyEventDispatcher(new java.awt.KeyEventDispatcher()
            {
                public boolean dispatchKeyEvent(java.awt.event.KeyEvent event)
                {
                    String key = javax.swing.KeyStroke.getKeyStrokeForEvent(event).toString();
                    if (key.equals("pressed UP"))
                        if(notBlocked(0))//see notBlocked(int)
                            player.setDirection(0);
                    if (key.equals("pressed RIGHT"))
                        if(notBlocked(90))
                            player.setDirection(90);
                    if (key.equals("pressed DOWN"))
                        if(notBlocked(180))
                            player.setDirection(180);
                    if (key.equals("pressed LEFT"))
                        if(notBlocked(270))
                            player.setDirection(270);
                    return true;
                }
            });
        world.show();
        updateScore();//lol last one I swear
    }

    public static void updateScore()
    {
        int playerScore = score;
        int playerLives = Manager.getLives();
        System.out.print("\f"); //clears the display screen and prints out the intitial lives and score
        System.out.println("Lives: " + Manager.getLives());
        System.out.println("Score: " + playerScore);
        //loops while the game is running
        while(true)
        {
            //onlye updates the display if there is a change in score or lives
            if(playerScore != score || playerLives !=  Manager.getLives())
            {
                playerScore = score; //sets the temp variable to score
                playerLives = Manager.getLives();//sets the temp variable to lives
                System.out.print("\f");//clears and updates the display
                System.out.println("Lives: " + Manager.getLives());
                System.out.println("Score: " + score);
            }
        }
    }

    public static void reset()
    {
        for(int r = 0; r < 23; r++)
        {
            for(int c = 0; c < 23; c++)
            {
                //finds ghosts, put Empty object in place to remove them from grid 
                if(world.getGrid().get(new Location(r,c)) instanceof Ghost)
                {
                    Empty e = new Empty();
                    e.putSelfInGrid(world.getGrid(),new Location(r,c));
                    createGhosts();//puts 4 new ghosts in cage
                }
            }
        }
        world.add(new Location (18, 13), player);//create a new playa cuz playa be dead bro
        Manager.subLives();//subtracts a life
    }

    public static boolean notBlocked(int dir)
    {
        Grid<Actor> gr = world.getGrid();
        //this is used to not allow player to turn into walls
        for(int r = 0; r < 23; r++)
        {
            for(int c = 0; c < 23; c++)
            {
                //iterates through grid, checks if player is found then
                //returns if location in from of player is valid and not wall
                Location myLoc = new Location(r,c);
                if(gr.get(myLoc) instanceof Player)
                {
                    //used to be just what is below for this method, but "player.getLocation" gave null pointer
                    //cuz player might not be in grid when button is pressed
                    Location other = player.getLocation().getAdjacentLocation(dir);
                    return  gr.isValid(other) && !(gr.get(other) instanceof Wall);
                }
            }
        }
        
        return false;
        //if player is not in grid, dont allow player to change direction
        //this stops null pointer exception
    }

    public static void createWalls()
    {
        //each corresponds to sections of wall object locations
        outerBorder();
        squares();
        middle();
        bottom();
    }

    public static void createGhosts()
    {
        //creates 4 ghosts and sets number of steps in start move sequence
        Ghost g1 = new Ghost();g1.setStart(2);
        Ghost g2 = new Ghost();g2.setStart(4);
        Ghost g3 = new Ghost();g3.setStart(6);
        Ghost g4 = new Ghost();g4.setStart(8);
        world.add(new Location (11, 9), g1);
        world.add(new Location (11, 10), g2);
        world.add(new Location (11, 12), g3);
        world.add(new Location (11, 13), g4);
    }

    public static void wall(int r, int c)
    {
        //helper method; used to shorten up code a bit
        world.add(new Location (r,c), new Wall());
    }
    
    public static void outerBorder()
    {
        //using for loops for these methods requires less typing, more thinking on our part
        for(int i = 0; i < 23; i++)
        {
            wall(0, i);
            wall(i, 0);
            wall(22, 22-i);
            wall(22-i, 22);
        }
        world.remove(new Location(9,0));
        world.remove(new Location(11,0));
        world.remove(new Location(13,0));
        world.remove(new Location(9,22));
        world.remove(new Location(11,22));
        world.remove(new Location(13,22));

        for(int r = 8; r <= 14; r += 2)
        {
            for(int c = 0; c < 5; c++)
            {
                wall(r,c);
                wall(r,c + 18);
            }
        }
        wall(9,4);
        wall(13,4);
        wall(9,18);
        wall(13,18);

        for(int r = 1; r <= 4; r++)
        {
            wall(r,11);
        }

        wall(18,1);
        wall(18,2);
        wall(18,20);
        wall(18,21);
    }

    public static void squares()
    {
        for(int r = 2; r <= 4; r += 2)
        {
            for(int c = 2; c <= 4; c++)
            {
                wall(r,c);
                wall(r,c + 16);
            }
            for(int c = 6; c <= 9; c++)
            {
                wall(r,c);
                wall(r,c + 7);
            }
            wall(3,2);
            wall(3,4);
            wall(3,6);
            wall(3,9);
            wall(3,13);
            wall(3,16);
            wall(3,18);
            wall(3,20);
        }
    }

    public static void middle()
    {
        for(int c = 2; c <= 4; c++)
        {
            wall(6,c);
            wall(6,c + 6);
            wall(6,c + 10);
            wall(6,c + 16);
            wall(8,c + 5);
            wall(8,c + 11);

            wall(c + 4,6);
            wall(c + 6,6);
            wall(c + 4,16);
            wall(c + 6,16);

            wall(c + 4,11);

            wall(10, c + 6);
            wall(13, c + 6);
            wall(10, c + 10);
            wall(13, c + 10);
            wall(c + 8,8);
            wall(c + 8,14);
        }
        wall(13,11);
    }

    public static void bottom()
    {
        for(int i = 0; i < 4; i++)
        {
            wall(i + 12,6);
            wall(i + 12,16);
            wall(15,i + 8);
            wall(15,i + 11);
            wall(17,i + 6);
            wall(17,i + 13);
            wall(20,i + 2);
            wall(20,i + 17);
        }
        for(int i = 0; i < 3; i++)
        {
            wall(i + 15,11);
            wall(16,i + 2);
            wall(16,i + 18);
            wall(i + 16,4);
            wall(i + 16,18);
            wall(19,i + 8);
            wall(19,i + 12);
        }
        for(int i = 0; i < 2; i++)
        {
            wall(i + 19,6);
            wall(i + 19,11);
            wall(i + 19,16);
        }
    }    

    public static void putPellets()
    {
        //puts pellets in locations that are not filled yet
        for(int r = 0; r < 23; r++)
        {
            for(int c = 0; c < 23; c++)
            {
                Location loc = new Location (r,c);
                if(world.getGrid().get(loc) == null)
                {
                    world.add(loc, new Pellet());
                }
            }
        }

        
        //puts Empty objects in locations that we dont want pellets in
        for(int i = 0; i <= 3; i++)
        {
            world.add(new Location (9,i), new Empty());
            world.add(new Location (13,i), new Empty());
            world.add(new Location (9,i + 19), new Empty());
            world.add(new Location (13,i + 19), new Empty());
            world.add(new Location (11,i + 9), new Empty());
            world.add(new Location (12,i + 9), new Empty());
        }

        world.add(new Location (3,3), new Empty());
        world.add(new Location (3,7), new Empty());
        world.add(new Location (3,8), new Empty());
        world.add(new Location (3,14), new Empty());
        world.add(new Location (3,15), new Empty());
        world.add(new Location (3,19), new Empty());
        world.add(new Location (11,13), new Empty());
        world.add(new Location (12,13), new Empty());
        world.add(new Location (10,11), new Empty());
        world.add(new Location (11,0), new Empty());
        world.add(new Location (11,22), new Empty());

        //puts power pellets
        world.add(new Location (17, 21), new PowerPellet());
        world.add(new Location (17, 1), new PowerPellet());
        world.add(new Location (3, 21), new PowerPellet());
        world.add(new Location (3, 1), new PowerPellet());
    }
}

