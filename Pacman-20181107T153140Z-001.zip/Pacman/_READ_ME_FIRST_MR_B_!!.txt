Yay you read me!
Here's a few things you need to know before you can play Pacman
For some reason the all the sprites got renamed "*file*.gif.png"
So, you must remove the ".png" for sprites to load correctly

Instructions to correctly load sprites:

Enable file extensions
	Control Panel > Appearance and Personalization > Folder Options > 
	    View Tab > Uncheck "Hide Extensions For Known File Types"
	Rename all images from pacman project directory from "*file*.png" or "*file*.jpg" to "*file*.gif"


Add gridworld.jar from Pacman directory
	BlueJ > Tools > Preferences > Libraries > add > navigate to gridworld.jar from Pacman Directory


Also, there are a few known bugs:
	Scared ghosts sometimes eats Player