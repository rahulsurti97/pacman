package projects.pacman;

import info.gridworld.actor.*;
import info.gridworld.grid.*;

import java.util.ArrayList;
import java.awt.Color;

/**
 * This is the object that is controlled by the player. It moves around the grid using the arrow keys.
 * It.Is.You.
 * 
 * @author (Sean Hurley and Rahul Surti) 
 * @version (Version 1.5: June 3, 2014)
 */
public class Player extends Bug //mimics the snakebugs movement
{
    private int grow;//uses same method to have a trail of droppings as SnakeBug uses for tail
    private ArrayList<Location> trail; //saves locations of dropping objects it leaves behind
    private int score; //game score
    public Player()
    {
        setColor(null); //we have our own sprites so we dont need a color
        trail = new ArrayList<Location>();
        grow = 7;
        score = 0;
    }

    public int getScore()//used so score can be saved in the runner
    {
        return score;
    }

    public void act() //same as snakeBug
    {
        if(canMove())
            move();
        if(grow > 0)    grow--;
        else            eraseTrail();
    }

    public void move() //how the player moves on the grid
    {
        Grid<Actor> gr = getGrid();
        if (gr == null)
            return;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        //used when player teleports from the right to the left side, or vice versa
        if(next.equals(new Location(11,0)))
        {
            next = new Location(11,21); //sets next location to the opposite side
        }
        else if(next.equals(new Location(11,22)))
        {
            next = new Location(11,1); //sets next location to the opposite side
        }
        
        if (gr.isValid(next))
        {
            if(gr.get(next) instanceof PowerPellet)
            {
                Pacman.setScore(50);//adds points to score
                findGhosts();//turns all ghosts into scaredGhosts.
            }
            else if(gr.get(next) instanceof Pellet)
                Pacman.setScore(10);
            moveTo(next);
        }
        addTrail(loc); //adds a dropping object behind it for the ghosts to follow
    }

    public void findGhosts()
    {
        //goes through the whole grid searching for ghosts
        for(int r = 0; r < 23; r++)//grid is 23 by 23
        {
            for(int c = 0; c < 23; c++)
            {
                if(getGrid().get(new Location(r,c)) instanceof Ghost)
                {
                    //if it finds a ghost, it replaces it with a scaredGhost in the same location
                    ScaredGhost scared = new ScaredGhost();
                    scared.putSelfInGrid(getGrid(),new Location(r,c));
                }  
            }
        }
    }

    public void addTrail(Location loc)//adds droppings when it moves, much like snakeBug
    {
        Grid<Actor> gr = getGrid();
        ActorWorld world = new ActorWorld();
        Dropping dropping = new Dropping();
        dropping.putSelfInGrid(gr, loc); //puts a dropping in the grid at location loc
        trail.add(0, loc);//adds the location to the arrayList after it has been put in the grid
    }

    public void eraseTrail()//removes droppings from the grid, and replaces them with and empty object
    {
        if(trail.size() > 0)
        {
            Grid<Actor> gr = getGrid();
            Location loc = (Location)(trail.get(trail.size()-1));
            Actor remove = gr.get(loc);
            if(remove instanceof Dropping)
            {
                //if a dropping is removed, an empty takes its place. Used so the background stays black
                remove.removeSelfFromGrid();
                Empty empty = new Empty();
                empty.putSelfInGrid(gr, loc);
            }
            trail.remove(loc);
        }
    }
}

