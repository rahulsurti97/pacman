package projects.pacman;

import info.gridworld.actor.*;
import info.gridworld.grid.*;
import java.util.ArrayList;
import java.util.Random;

/**
 * The AI enemy of the game. Designed to move randomly, but never move to the previous location
 * it was in. If it finds a Dropping object, it follows it to find the Player, the proceeds to brutally murder Player
 * 
 * @author (Sean Hurley and Rahul Surti) 
 * @version (Version 1.5: June 3, 2014)
 */
public class Ghost extends Critter//overrides and uses many methods from Critter
{
    Actor a1;//refer to move()
    Actor a2;//refer to move()
    Location lastLoc;//location the ghost was previously in
    Location startLoc;//location the ghost starts in
    int startMove;//how many times the ghost moves in the start sequence
    boolean start;//used for start sequence

    public Ghost()
    {
        setColor(null);//show true ghost color
        a1 = new Empty();//for first move; refer to move()
        startLoc = new Location(11,9);//used for start sequence
        start = true;//do start sequence if not otherwise changed with setBool()
    }

    //we did not implement in the constructor because of problems with ScaredGhost
    public void setStart(int s)
    {
        //set number of steps to do start sequence
        startMove = s;
    }
    public void setBool(boolean b)
    {
        //if true, do start sequence in cage, otherwise dont
        start = b;
    }
    
    public void act()
    {
        Location ofart = new Location(9,11);//where the ghosts start after the start sequence
        if(startMove > 0)
        {
            //moves the ghost up and down startMove times in the starting location
            if(getLocation().getRow() == (startLoc.getRow()))
            {
                moveTo(new Location(getLocation().getRow() + 1, getLocation().getCol()));
                startMove--;
                Empty e = new Empty();//puts an empty object in so the background stays black
                e.putSelfInGrid(getGrid(),new Location(getLocation().getRow() - 1, getLocation().getCol()));
            }
            else
            {
                moveTo(new Location(getLocation().getRow() - 1, getLocation().getCol()));
                startMove--;
                Empty e = new Empty();
                e.putSelfInGrid(getGrid(),new Location(getLocation().getRow() + 1, getLocation().getCol()));
            }
        }
        else
        {
            if(start)
            {
                //when startMove hits 0, the ghosts are moved out of their start position and the
                //sequence is finished.
                move(ofart);
                start = false; //ends the start sequence
            }
            move(selectMoveLocations(getMoveLocations())); //makes its move
        }
    }

    public ArrayList<Location> getMoveLocations()
    {
        ArrayList<Location> locs = new ArrayList<Location>(); //creates the ArrayList it will return
        Grid<Actor> gr = getGrid(); //gets the grid for ease of use
        for(int i = 0; i < 360; i += 90)
            //adds the four locations north, south, east, and west to locs
            locs.add(getLocation().getAdjacentLocation(i));
        for(int i = locs.size() - 1; i >= 0; i--)
        {
            //stops the ghost from moving back into the start area, into a wall, or out of grid
            boolean entrance = locs.get(i).equals(new Location(10, 11)) || locs.get(i).equals(new Location(11, 11));
            boolean notValid = !gr.isValid(locs.get(i)) || gr.get(locs.get(i)) instanceof Wall;
            if (entrance || notValid)
                locs.remove(i); //erases the location from locs
        }
        for(int i = 0; i < locs.size() - 1; i++)
        {
            //if a player is found it immediately returns that position in a new ArrayList
            ArrayList<Location> arr = new ArrayList<Location>();
            if(gr.get(locs.get(i)) instanceof Player)
            {   
                arr.add(locs.get(i));
                return arr;
            }                                          
        }
        //stops the ghost from moving to its previous location
        for(int i = locs.size() - 1; i >= 0; i--)
            if (locs.get(i).equals(lastLoc))
                locs.remove(i);
        return locs;
    }

    public Location selectMoveLocations(ArrayList<Location> locs)
    {
        Grid<Actor> gr = getGrid();
        /*if the ghost is near the teleport locations on the left and right, it doesn't add and locations
         * to locs. So, if the size is zero, we know it is in one of the two teleport locations.
         * It then tests to see which location it is in, and returns the other side as its next location
         */
        if(locs.size() == 0)
        {
            if(getLocation().equals(new Location(11,0)))
                return new Location(11,21);
            if(getLocation().equals(new Location(11,22)))
                return new Location(11,1);
        }
        //gives priority to droppings and the player. If not found, selects a random location
        for(Location loc: locs)
            if(gr.get(loc) instanceof Player || gr.get(loc) instanceof Dropping)
                return loc;
        
                
        //otherwise, return random location from array
        int r = (int) (Math.random() * locs.size());
        return locs.get(r);
    }

    public void move(Location loc)
    {
        //allows ghosts to move over empty & pellet objects without deleting them
        //by storing the object it is currently on and placing it the next act
        Grid<Actor> gr = getGrid();
        lastLoc = getLocation();
        a2 = gr.get(loc);//saves actor from my location
        moveTo(loc);//moves to that location
        a1.putSelfInGrid(gr,lastLoc);//puts the saved actor from the last move in the last location
        a1 = a2;//actor saved from this move is saved to be put in next act
    }
}

